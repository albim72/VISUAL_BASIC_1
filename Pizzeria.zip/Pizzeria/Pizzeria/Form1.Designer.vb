﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim GroupBox2 As System.Windows.Forms.GroupBox
        Me.rb_grube = New System.Windows.Forms.RadioButton()
        Me.rb_standard = New System.Windows.Forms.RadioButton()
        Me.rb_cienkie = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rb_duza = New System.Windows.Forms.RadioButton()
        Me.rb_srednia = New System.Windows.Forms.RadioButton()
        Me.rb_mala = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cb_czo = New System.Windows.Forms.CheckBox()
        Me.cb_tun = New System.Windows.Forms.CheckBox()
        Me.cd_szy = New System.Windows.Forms.CheckBox()
        Me.cb_pom = New System.Windows.Forms.CheckBox()
        Me.cb_ser = New System.Windows.Forms.CheckBox()
        Me.cb_pie = New System.Windows.Forms.CheckBox()
        Me.cb_ceb = New System.Windows.Forms.CheckBox()
        Me.cb_pep = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.rtb = New System.Windows.Forms.RichTextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        GroupBox2 = New System.Windows.Forms.GroupBox()
        GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        GroupBox2.Controls.Add(Me.rb_grube)
        GroupBox2.Controls.Add(Me.rb_standard)
        GroupBox2.Controls.Add(Me.rb_cienkie)
        GroupBox2.Location = New System.Drawing.Point(747, 164)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New System.Drawing.Size(464, 373)
        GroupBox2.TabIndex = 1
        GroupBox2.TabStop = False
        GroupBox2.Text = "Ciasto"
        '
        'rb_grube
        '
        Me.rb_grube.AutoSize = True
        Me.rb_grube.Location = New System.Drawing.Point(67, 285)
        Me.rb_grube.Name = "rb_grube"
        Me.rb_grube.Size = New System.Drawing.Size(125, 36)
        Me.rb_grube.TabIndex = 2
        Me.rb_grube.TabStop = True
        Me.rb_grube.Text = "grube"
        Me.rb_grube.UseVisualStyleBackColor = True
        '
        'rb_standard
        '
        Me.rb_standard.AutoSize = True
        Me.rb_standard.Location = New System.Drawing.Point(67, 181)
        Me.rb_standard.Name = "rb_standard"
        Me.rb_standard.Size = New System.Drawing.Size(163, 36)
        Me.rb_standard.TabIndex = 1
        Me.rb_standard.TabStop = True
        Me.rb_standard.Text = "standard"
        Me.rb_standard.UseVisualStyleBackColor = True
        '
        'rb_cienkie
        '
        Me.rb_cienkie.AutoSize = True
        Me.rb_cienkie.Location = New System.Drawing.Point(67, 87)
        Me.rb_cienkie.Name = "rb_cienkie"
        Me.rb_cienkie.Size = New System.Drawing.Size(142, 36)
        Me.rb_cienkie.TabIndex = 0
        Me.rb_cienkie.TabStop = True
        Me.rb_cienkie.Text = "cienkie"
        Me.rb_cienkie.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rb_duza)
        Me.GroupBox1.Controls.Add(Me.rb_srednia)
        Me.GroupBox1.Controls.Add(Me.rb_mala)
        Me.GroupBox1.Location = New System.Drawing.Point(102, 164)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(458, 393)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Rozmiar"
        '
        'rb_duza
        '
        Me.rb_duza.AutoSize = True
        Me.rb_duza.Location = New System.Drawing.Point(37, 304)
        Me.rb_duza.Name = "rb_duza"
        Me.rb_duza.Size = New System.Drawing.Size(114, 36)
        Me.rb_duza.TabIndex = 2
        Me.rb_duza.TabStop = True
        Me.rb_duza.Text = "duża"
        Me.rb_duza.UseVisualStyleBackColor = True
        '
        'rb_srednia
        '
        Me.rb_srednia.AutoSize = True
        Me.rb_srednia.Location = New System.Drawing.Point(37, 200)
        Me.rb_srednia.Name = "rb_srednia"
        Me.rb_srednia.Size = New System.Drawing.Size(146, 36)
        Me.rb_srednia.TabIndex = 1
        Me.rb_srednia.TabStop = True
        Me.rb_srednia.Text = "średnia"
        Me.rb_srednia.UseVisualStyleBackColor = True
        '
        'rb_mala
        '
        Me.rb_mala.AutoSize = True
        Me.rb_mala.Location = New System.Drawing.Point(37, 106)
        Me.rb_mala.Name = "rb_mala"
        Me.rb_mala.Size = New System.Drawing.Size(114, 36)
        Me.rb_mala.TabIndex = 0
        Me.rb_mala.TabStop = True
        Me.rb_mala.Text = "mała"
        Me.rb_mala.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cb_czo)
        Me.GroupBox3.Controls.Add(Me.cb_tun)
        Me.GroupBox3.Controls.Add(Me.cd_szy)
        Me.GroupBox3.Controls.Add(Me.cb_pom)
        Me.GroupBox3.Controls.Add(Me.cb_ser)
        Me.GroupBox3.Controls.Add(Me.cb_pie)
        Me.GroupBox3.Controls.Add(Me.cb_ceb)
        Me.GroupBox3.Controls.Add(Me.cb_pep)
        Me.GroupBox3.Location = New System.Drawing.Point(1404, 164)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(412, 759)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Dodatki"
        '
        'cb_czo
        '
        Me.cb_czo.AutoSize = True
        Me.cb_czo.Location = New System.Drawing.Point(27, 703)
        Me.cb_czo.Name = "cb_czo"
        Me.cb_czo.Size = New System.Drawing.Size(157, 36)
        Me.cb_czo.TabIndex = 0
        Me.cb_czo.Text = "czosnek"
        Me.cb_czo.UseVisualStyleBackColor = True
        '
        'cb_tun
        '
        Me.cb_tun.AutoSize = True
        Me.cb_tun.Location = New System.Drawing.Point(27, 610)
        Me.cb_tun.Name = "cb_tun"
        Me.cb_tun.Size = New System.Drawing.Size(149, 36)
        Me.cb_tun.TabIndex = 0
        Me.cb_tun.Text = "tuńczyk"
        Me.cb_tun.UseVisualStyleBackColor = True
        '
        'cd_szy
        '
        Me.cd_szy.AutoSize = True
        Me.cd_szy.Location = New System.Drawing.Point(27, 357)
        Me.cd_szy.Name = "cd_szy"
        Me.cd_szy.Size = New System.Drawing.Size(141, 36)
        Me.cd_szy.TabIndex = 0
        Me.cd_szy.Text = "szynka"
        Me.cd_szy.UseVisualStyleBackColor = True
        '
        'cb_pom
        '
        Me.cb_pom.AutoSize = True
        Me.cb_pom.Location = New System.Drawing.Point(27, 522)
        Me.cb_pom.Name = "cb_pom"
        Me.cb_pom.Size = New System.Drawing.Size(156, 36)
        Me.cb_pom.TabIndex = 0
        Me.cb_pom.Text = "pomidor"
        Me.cb_pom.UseVisualStyleBackColor = True
        '
        'cb_ser
        '
        Me.cb_ser.AutoSize = True
        Me.cb_ser.Location = New System.Drawing.Point(27, 264)
        Me.cb_ser.Name = "cb_ser"
        Me.cb_ser.Size = New System.Drawing.Size(92, 36)
        Me.cb_ser.TabIndex = 0
        Me.cb_ser.Text = "ser"
        Me.cb_ser.UseVisualStyleBackColor = True
        '
        'cb_pie
        '
        Me.cb_pie.AutoSize = True
        Me.cb_pie.Location = New System.Drawing.Point(27, 440)
        Me.cb_pie.Name = "cb_pie"
        Me.cb_pie.Size = New System.Drawing.Size(166, 36)
        Me.cb_pie.TabIndex = 0
        Me.cb_pie.Text = "pieczarki"
        Me.cb_pie.UseVisualStyleBackColor = True
        '
        'cb_ceb
        '
        Me.cb_ceb.AutoSize = True
        Me.cb_ceb.Location = New System.Drawing.Point(27, 176)
        Me.cb_ceb.Name = "cb_ceb"
        Me.cb_ceb.Size = New System.Drawing.Size(138, 36)
        Me.cb_ceb.TabIndex = 0
        Me.cb_ceb.Text = "cebula"
        Me.cb_ceb.UseVisualStyleBackColor = True
        '
        'cb_pep
        '
        Me.cb_pep.AutoSize = True
        Me.cb_pep.Location = New System.Drawing.Point(27, 94)
        Me.cb_pep.Name = "cb_pep"
        Me.cb_pep.Size = New System.Drawing.Size(181, 36)
        Me.cb_pep.TabIndex = 0
        Me.cb_pep.Text = "pepperoni"
        Me.cb_pep.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(111, 573)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(163, 32)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Rezerwacja"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(757, 573)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 32)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Odbiór"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 31
        Me.ListBox1.Items.AddRange(New Object() {"12", "12:30", "13", "13:30", "14", "14:30", "15", "15:30", "16", "16:30", "17", "17:30", "18", "18:30", "19", "19:30", "20", "20:30", "21", "21:30", "22", "22:30"})
        Me.ListBox1.Location = New System.Drawing.Point(102, 651)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(465, 252)
        Me.ListBox1.TabIndex = 4
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 31
        Me.ListBox2.Items.AddRange(New Object() {"osobisty", "dowóz", "kurier", "catering"})
        Me.ListBox2.Location = New System.Drawing.Point(746, 651)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(465, 252)
        Me.ListBox2.TabIndex = 4
        '
        'rtb
        '
        Me.rtb.Location = New System.Drawing.Point(102, 987)
        Me.rtb.Name = "rtb"
        Me.rtb.Size = New System.Drawing.Size(1714, 353)
        Me.rtb.TabIndex = 5
        Me.rtb.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(102, 1413)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(390, 64)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Zamówienie"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(556, 1413)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(390, 64)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Kwota"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(997, 1413)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(390, 64)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "Zamknij"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(1426, 1413)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(390, 64)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "Wyczyść"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(16.0!, 31.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(3806, 1970)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.rtb)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.MinimumSize = New System.Drawing.Size(3838, 2058)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PIZZERIA"
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rb_duza As RadioButton
    Friend WithEvents rb_srednia As RadioButton
    Friend WithEvents rb_mala As RadioButton
    Friend WithEvents rb_grube As RadioButton
    Friend WithEvents rb_standard As RadioButton
    Friend WithEvents rb_cienkie As RadioButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents cb_czo As CheckBox
    Friend WithEvents cb_tun As CheckBox
    Friend WithEvents cd_szy As CheckBox
    Friend WithEvents cb_pom As CheckBox
    Friend WithEvents cb_ser As CheckBox
    Friend WithEvents cb_pie As CheckBox
    Friend WithEvents cb_ceb As CheckBox
    Friend WithEvents cb_pep As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents rtb As RichTextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
End Class
