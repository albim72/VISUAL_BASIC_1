﻿Public Class Form1
    Private Const V As Integer = 0
    Dim msRozm As String
    Dim mdCena As Decimal
    Dim mdKwota As Decimal
    Dim msCiasto As String
    Dim msDodatki As String
    Dim TotalCena As Decimal


    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles cd_szy.CheckedChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        rtb.ResetText()
        cb_ceb.Checked = False
        cb_czo.Checked = False
        cb_pep.Checked = False
        cb_pie.Checked = False
        cb_pom.Checked = False
        cb_ser.Checked = False
        cb_tun.Checked = False

        Button1.Enabled = True

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub Rb_mala_CheckedChanged(sender As Object, e As EventArgs) Handles rb_mala.CheckedChanged
        msRozm = "mała pizza"
        mdCena = 15

    End Sub

    Private Sub Rb_srednia_CheckedChanged(sender As Object, e As EventArgs) Handles rb_srednia.CheckedChanged
        msRozm = "średnia pizza"
        mdCena = 20
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.SelectedItem() = "13"
    End Sub

    Private Sub Rb_duza_CheckedChanged(sender As Object, e As EventArgs) Handles rb_duza.CheckedChanged
        msRozm = "duża pizza"
        mdCena = 26
    End Sub

    Private Sub Rb_cienkie_CheckedChanged(sender As Object, e As EventArgs) Handles rb_cienkie.CheckedChanged
        msCiasto = "ciasto cienkie"

    End Sub

    Private Sub Rb_standard_CheckedChanged(sender As Object, e As EventArgs) Handles rb_standard.CheckedChanged
        msCiasto = "ciasto standardowe"

    End Sub

    Private Sub Rb_grube_CheckedChanged(sender As Object, e As EventArgs) Handles rb_grube.CheckedChanged
        msCiasto = "ciasto grube"

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        rtb.AppendText("Zamówienie pizzy: " & ControlChars.Tab & "rozmiar pizzy: " _
            & msRozm.PadRight(12) & vbNewLine)
        rtb.AppendText("Cena pizzy: " & mdCena & vbNewLine)
        rtb.AppendText("Grubość ciasta: " & msCiasto & vbNewLine)

        TotalCena += mdCena

        Dim str = ""

        If cb_ceb.Checked = True Then
            str &= cb_ceb.Text & ", "
        End If
        If cb_czo.Checked = True Then
            str &= cb_czo.Text & ", "
        End If
        If cb_pep.Checked = True Then
            str &= cb_pep.Text & ", "
        End If
        If cb_pie.Checked = True Then
            str &= cb_pie.Text & ", "
        End If
        If cb_pom.Checked = True Then
            str &= cb_pom.Text & ", "
        End If
        If cb_ser.Checked = True Then
            str &= cb_ser.Text & ", "
        End If
        If cb_ceb.Checked = True Then
            str &= cb_ceb.Text & ", "
        End If
        If cb_tun.Checked = True Then
            str &= cb_tun.Text & ", "
        End If


        If str <> Nothing Then
            rtb.AppendText("Dodatki: " & str & vbNewLine)
        End If

        rtb.AppendText("Godzina dotawy: " & ListBox1.Text & vbNewLine)
        rtb.AppendText("Odbiór: " & ListBox2.Text & vbNewLine)



    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        rtb.AppendText("Wartość zamówienia: " & TotalCena & vbNewLine)
        rtb.AppendText("Dziękujemy za zamówienie!")
        Button1.Enabled = False

    End Sub
End Class
