﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbMetry = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnPolicz = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbWynik = New System.Windows.Forms.TextBox()
        Me.btnOpis = New System.Windows.Forms.Button()
        Me.btnZamknij = New System.Windows.Forms.Button()
        Me.rbMilaM = New System.Windows.Forms.RadioButton()
        Me.rbMilaL = New System.Windows.Forms.RadioButton()
        Me.rbJard = New System.Windows.Forms.RadioButton()
        Me.rbStopa = New System.Windows.Forms.RadioButton()
        Me.rbCal = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Green
        Me.Label1.Location = New System.Drawing.Point(30, 27)
        Me.Label1.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(175, 22)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Kalkulator odległości"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 77)
        Me.Label2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "podaj wartość w [m]"
        '
        'tbMetry
        '
        Me.tbMetry.Location = New System.Drawing.Point(197, 74)
        Me.tbMetry.Margin = New System.Windows.Forms.Padding(1)
        Me.tbMetry.Name = "tbMetry"
        Me.tbMetry.Size = New System.Drawing.Size(249, 20)
        Me.tbMetry.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbCal)
        Me.GroupBox1.Controls.Add(Me.rbStopa)
        Me.GroupBox1.Controls.Add(Me.rbJard)
        Me.GroupBox1.Controls.Add(Me.rbMilaL)
        Me.GroupBox1.Controls.Add(Me.rbMilaM)
        Me.GroupBox1.Location = New System.Drawing.Point(72, 134)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Size = New System.Drawing.Size(228, 187)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "wybierz miarę"
        '
        'btnPolicz
        '
        Me.btnPolicz.Location = New System.Drawing.Point(326, 246)
        Me.btnPolicz.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPolicz.Name = "btnPolicz"
        Me.btnPolicz.Size = New System.Drawing.Size(195, 37)
        Me.btnPolicz.TabIndex = 4
        Me.btnPolicz.Text = "policz odległość"
        Me.btnPolicz.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(69, 346)
        Me.Label3.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "wynik"
        '
        'tbWynik
        '
        Me.tbWynik.Enabled = False
        Me.tbWynik.Location = New System.Drawing.Point(197, 346)
        Me.tbWynik.Margin = New System.Windows.Forms.Padding(1)
        Me.tbWynik.Name = "tbWynik"
        Me.tbWynik.Size = New System.Drawing.Size(249, 20)
        Me.tbWynik.TabIndex = 6
        '
        'btnOpis
        '
        Me.btnOpis.Location = New System.Drawing.Point(108, 398)
        Me.btnOpis.Margin = New System.Windows.Forms.Padding(1)
        Me.btnOpis.Name = "btnOpis"
        Me.btnOpis.Size = New System.Drawing.Size(115, 48)
        Me.btnOpis.TabIndex = 7
        Me.btnOpis.Text = "opis"
        Me.btnOpis.UseVisualStyleBackColor = True
        '
        'btnZamknij
        '
        Me.btnZamknij.Location = New System.Drawing.Point(406, 398)
        Me.btnZamknij.Margin = New System.Windows.Forms.Padding(1)
        Me.btnZamknij.Name = "btnZamknij"
        Me.btnZamknij.Size = New System.Drawing.Size(115, 48)
        Me.btnZamknij.TabIndex = 7
        Me.btnZamknij.Text = "zamknij"
        Me.btnZamknij.UseVisualStyleBackColor = True
        '
        'rbMilaM
        '
        Me.rbMilaM.AutoSize = True
        Me.rbMilaM.Location = New System.Drawing.Point(27, 31)
        Me.rbMilaM.Name = "rbMilaM"
        Me.rbMilaM.Size = New System.Drawing.Size(82, 17)
        Me.rbMilaM.TabIndex = 0
        Me.rbMilaM.TabStop = True
        Me.rbMilaM.Text = "Mila Morska"
        Me.rbMilaM.UseVisualStyleBackColor = True
        '
        'rbMilaL
        '
        Me.rbMilaL.AutoSize = True
        Me.rbMilaL.Location = New System.Drawing.Point(27, 61)
        Me.rbMilaL.Name = "rbMilaL"
        Me.rbMilaL.Size = New System.Drawing.Size(85, 17)
        Me.rbMilaL.TabIndex = 0
        Me.rbMilaL.TabStop = True
        Me.rbMilaL.Text = "Mila Lądowa"
        Me.rbMilaL.UseVisualStyleBackColor = True
        '
        'rbJard
        '
        Me.rbJard.AutoSize = True
        Me.rbJard.Location = New System.Drawing.Point(27, 91)
        Me.rbJard.Name = "rbJard"
        Me.rbJard.Size = New System.Drawing.Size(45, 17)
        Me.rbJard.TabIndex = 0
        Me.rbJard.TabStop = True
        Me.rbJard.Text = "Jard"
        Me.rbJard.UseVisualStyleBackColor = True
        '
        'rbStopa
        '
        Me.rbStopa.AutoSize = True
        Me.rbStopa.Location = New System.Drawing.Point(27, 121)
        Me.rbStopa.Name = "rbStopa"
        Me.rbStopa.Size = New System.Drawing.Size(53, 17)
        Me.rbStopa.TabIndex = 0
        Me.rbStopa.TabStop = True
        Me.rbStopa.Text = "Stopa"
        Me.rbStopa.UseVisualStyleBackColor = True
        '
        'rbCal
        '
        Me.rbCal.AutoSize = True
        Me.rbCal.Location = New System.Drawing.Point(27, 151)
        Me.rbCal.Name = "rbCal"
        Me.rbCal.Size = New System.Drawing.Size(40, 17)
        Me.rbCal.TabIndex = 0
        Me.rbCal.TabStop = True
        Me.rbCal.Text = "Cal"
        Me.rbCal.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(699, 479)
        Me.Controls.Add(Me.btnZamknij)
        Me.Controls.Add(Me.btnOpis)
        Me.Controls.Add(Me.tbWynik)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnPolicz)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.tbMetry)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.Name = "Form1"
        Me.Text = "kalkulator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tbMetry As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnPolicz As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents tbWynik As TextBox
    Friend WithEvents btnOpis As Button
    Friend WithEvents btnZamknij As Button
    Friend WithEvents rbCal As RadioButton
    Friend WithEvents rbStopa As RadioButton
    Friend WithEvents rbJard As RadioButton
    Friend WithEvents rbMilaL As RadioButton
    Friend WithEvents rbMilaM As RadioButton
End Class
